import os

# Flask utils
from flask import Flask, redirect, url_for, request, render_template
from werkzeug.utils import secure_filename
#from keras.models import load_model

import keras
from keras.models import Sequential
from keras.layers import Dense,Dropout,Flatten
from keras.layers import Conv2D,MaxPooling2D,Activation,AveragePooling2D,BatchNormalization
from keras.preprocessing.image import ImageDataGenerator

from keras.models import load_model

from keras.preprocessing import image

import numpy as np

import sys
from PIL import Image
sys.modules['Image'] = Image 

# Define a flask app
app = Flask(__name__)

'''# Model saved with Keras model.save()
MODEL_PATH ='D:/Engineering/Final Project/Coffee App/model4.h5'

# Load your trained model
model = load_weights(MODEL_PATH)'''

num_classes = 3
img_width,img_height =256,256
input_shape=(img_width,img_height,3)

model = Sequential()
model.add(Conv2D(32, (5, 5),input_shape=input_shape,activation='relu'))
model.add(MaxPooling2D(pool_size=(3, 3)))
model.add(Conv2D(32, (3, 3),activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))
model.add(Conv2D(64, (3, 3),activation='relu'))
model.add(MaxPooling2D(pool_size=(2, 2)))   
model.add(Flatten())
model.add(Dense(64,activation='relu'))
model.add(Dropout(0.25))
model.add(Dense(64,activation='relu'))          
model.add(Dense(num_classes,activation='softmax'))

'''new_model = load_model('D:/Engineering/Final Project/Coffee App/model4.h5')
new_model.get_weights()
print("Weights",new_model.get_weights())'''

model_layers = [ layer.name for layer in model.layers]
print('layer name : ',model_layers)

model.compile(optimizer='adam',loss='categorical_crossentropy',metrics=['accuracy'])
model.load_weights('D:/Engineering/Final Project/Coffee App/model4.h5')


def prepare(file_path):
    img=image.load_img(file_path,target_size=(256,256))
    x=image.img_to_array(img)
    x=x/255
    x = np.expand_dims(x,axis=0)
    return x

def model_predict(file_path):
    '''print(img_path)
    img = image.load_img(img_path, target_size=(256, 256))

    # Preprocessing the image
    x = image.img_to_array(img)
    # x = np.true_divide(x, 255)
    ## Scaling
    x=x/255
    x = np.expand_dims(x, axis=0)'''
   

    # Be careful how your trained model deals with the input
    # otherwise, it won't make correct prediction!
   # x = preprocess_input(x)

    #preds = model.predict(x)
    preds = model.predict([prepare(file_path)])
    preds=np.argmax(preds, axis=1)
    if preds==0:
        preds="The leaf is Healthy"
    elif preds==1:
        preds="The leaf is Red Spider Mite"
    elif preds==2:
        preds="The leaf is Rust"
    else:
        preds="Invalid"
    return preds

    

@app.route('/', methods=['GET'])
def index():
    # Main page
    return render_template('index.html')


@app.route('/predict', methods=['GET', 'POST'])
def upload():
    if request.method == 'POST':
        # Get the file from post request
        f = request.files['file']

        # Save the file to ./uploads
        basepath = os.path.dirname(__file__)
        file_path = os.path.join(
            basepath, 'uploads', secure_filename(f.filename))
        f.save(file_path)

        # Make prediction
        preds = model_predict(file_path)
        result=preds
        return result
    return None


if __name__ == '__main__':
    app.run(port=5001,debug=True)